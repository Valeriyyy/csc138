import os
import sys
from socket import *

#Valeriy Kutsar Socket 2
#ip = 192.168.1.74
serverPort = 80
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('',serverPort))
serverSocket.listen(1)

while True:
    print("ready to serve...")
    connectionSocket, addr = serverSocket.accept()

    try:
        message = connectionSocket.recv(1024) #fill in start
        print(message)

        filename = message.split()[1]
        print filename
        f = open(filename[1:])
        outputdata = f.read()
        print outputdata

        connectionSocket.send('HTTP/1.1 200 OK\n')
        connectionSocket.send("Connection: close \n")
        LengthString = "Content-Length: " + str(len(outputdata))
        connectionSocket.send(LengthString)
        connectionSocket.send("Content-Type: text/html \n\n\n")
        connectionSocket.send(outputdata)


        connectionSocket.close()
    except IOError:
        connectionSocket.send("\n")
        Message404 = "404 Not Found: " + filename + "\n"
        connectionSocket.send(Message404)
        connectionSocket.close()
serverSocket.close()
pass
sys.exit()